import pyautogui
import cv2
import numpy as np
import time
import sys
import keyboard
from tkinter import *

print("Programme lancée ...")
print("Tu ne doit pas fermer cette fenetre. (sinon le bot ne fonctinnera pas)")

while True:
    # Charger l'image que le bot doit reconnaître
    image_to_find = 'IMG/il.png'
    template = cv2.imread(image_to_find)
    template_gray = cv2.cvtColor(template, cv2.COLOR_BGR2GRAY)
    w, h = template_gray.shape[::-1]

    # Fonction pour trouver et cliquer sur l'image
    def find_and_click(image):
        # Prendre une capture d'écran
        screenshot = pyautogui.screenshot()
        screenshot = cv2.cvtColor(np.array(screenshot), cv2.COLOR_RGB2BGR)
        gray_screenshot = cv2.cvtColor(screenshot, cv2.COLOR_BGR2GRAY)

        # Reconnaissance de l'image
        res = cv2.matchTemplate(gray_screenshot, image, cv2.TM_CCOEFF_NORMED)
        threshold = 0.8
        loc = np.where(res >= threshold)

        # Cliquer sur l'image si elle est trouvée
        for pt in zip(*loc[::-1]):
            pyautogui.click(pt[0] + w/2, pt[1] + h/2)
            break

    # Appeler la fonction
    find_and_click(template_gray)



    # Charger l'image que le bot doit reconnaître
    image_to_find = 'IMG/suivant.png'
    template = cv2.imread(image_to_find)
    template_gray = cv2.cvtColor(template, cv2.COLOR_BGR2GRAY)
    w, h = template_gray.shape[::-1]

    # Fonction pour trouver et cliquer sur l'image
    def find_and_click(image):
        # Prendre une capture d'écran
        screenshot = pyautogui.screenshot()
        screenshot = cv2.cvtColor(np.array(screenshot), cv2.COLOR_RGB2BGR)
        gray_screenshot = cv2.cvtColor(screenshot, cv2.COLOR_BGR2GRAY)

        # Reconnaissance de l'image
        res = cv2.matchTemplate(gray_screenshot, image, cv2.TM_CCOEFF_NORMED)
        threshold = 0.8
        loc = np.where(res >= threshold)

        # Cliquer sur l'image si elle est trouvée
        for pt in zip(*loc[::-1]):
            pyautogui.click(pt[0] + w/2, pt[1] + h/2)
            break

    # Appeler la fonction
    find_and_click(template_gray)



    # Charger l'image que le bot doit reconnaître
    image_to_find = 'IMG/cont.png'
    template = cv2.imread(image_to_find)
    template_gray = cv2.cvtColor(template, cv2.COLOR_BGR2GRAY)
    w, h = template_gray.shape[::-1]

    # Fonction pour trouver et cliquer sur l'image
    def find_and_click(image):
        # Prendre une capture d'écran
        screenshot = pyautogui.screenshot()
        screenshot = cv2.cvtColor(np.array(screenshot), cv2.COLOR_RGB2BGR)
        gray_screenshot = cv2.cvtColor(screenshot, cv2.COLOR_BGR2GRAY)

        # Reconnaissance de l'image
        res = cv2.matchTemplate(gray_screenshot, image, cv2.TM_CCOEFF_NORMED)
        threshold = 0.8
        loc = np.where(res >= threshold)

        # Cliquer sur l'image si elle est trouvée
        for pt in zip(*loc[::-1]):
            pyautogui.click(pt[0] + w/2, pt[1] + h/2)
            break

    # Appeler la fonction
    find_and_click(template_gray)



    # Charger l'image que le bot doit reconnaître
    image_to_find = 'IMG/cont2.png'
    template = cv2.imread(image_to_find)
    template_gray = cv2.cvtColor(template, cv2.COLOR_BGR2GRAY)
    w, h = template_gray.shape[::-1]

    # Fonction pour trouver et cliquer sur l'image
    def find_and_click(image):
        # Prendre une capture d'écran
        screenshot = pyautogui.screenshot()
        screenshot = cv2.cvtColor(np.array(screenshot), cv2.COLOR_RGB2BGR)
        gray_screenshot = cv2.cvtColor(screenshot, cv2.COLOR_BGR2GRAY)

        # Reconnaissance de l'image
        res = cv2.matchTemplate(gray_screenshot, image, cv2.TM_CCOEFF_NORMED)
        threshold = 0.8
        loc = np.where(res >= threshold)

        # Cliquer sur l'image si elle est trouvée
        for pt in zip(*loc[::-1]):
            pyautogui.click(pt[0] + w/2, pt[1] + h/2)
            break

    # Appeler la fonction
    find_and_click(template_gray)



    # Charger l'image que le bot doit reconnaître
    image_to_find = 'IMG/cor.png'
    template = cv2.imread(image_to_find)
    template_gray = cv2.cvtColor(template, cv2.COLOR_BGR2GRAY)
    w, h = template_gray.shape[::-1]

    # Fonction pour trouver et cliquer sur l'image
    def find_and_click(image):
        # Prendre une capture d'écran
        screenshot = pyautogui.screenshot()
        screenshot = cv2.cvtColor(np.array(screenshot), cv2.COLOR_RGB2BGR)
        gray_screenshot = cv2.cvtColor(screenshot, cv2.COLOR_BGR2GRAY)

        # Reconnaissance de l'image
        res = cv2.matchTemplate(gray_screenshot, image, cv2.TM_CCOEFF_NORMED)
        threshold = 0.8
        loc = np.where(res >= threshold)

        # Cliquer sur l'image si elle est trouvée
        for pt in zip(*loc[::-1]):
            pyautogui.click(pt[0] + w/2, pt[1] + h/2)
            break

    # Appeler la fonction
    find_and_click(template_gray)



    # Charger l'image que le bot doit reconnaître
    image_to_find = 'IMG/inc.png'
    template = cv2.imread(image_to_find)
    template_gray = cv2.cvtColor(template, cv2.COLOR_BGR2GRAY)
    w, h = template_gray.shape[::-1]

    # Fonction pour trouver et cliquer sur l'image
    def find_and_click(image):
        # Prendre une capture d'écran
        screenshot = pyautogui.screenshot()
        screenshot = cv2.cvtColor(np.array(screenshot), cv2.COLOR_RGB2BGR)
        gray_screenshot = cv2.cvtColor(screenshot, cv2.COLOR_BGR2GRAY)

        # Reconnaissance de l'image
        res = cv2.matchTemplate(gray_screenshot, image, cv2.TM_CCOEFF_NORMED)
        threshold = 0.8
        loc = np.where(res >= threshold)

        # Cliquer sur l'image si elle est trouvée
        for pt in zip(*loc[::-1]):
            pyautogui.click(pt[0] + w/2, pt[1] + h/2)
            break

    # Appeler la fonction
    find_and_click(template_gray)